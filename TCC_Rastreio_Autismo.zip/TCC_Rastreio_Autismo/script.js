const botao = document.querySelector('.menu-btn');
const menu = document.querySelector('.menu');
botao.addEventListener('click', () => menu.classList.toggle('aberto'));
document.querySelectorAll('.menu a').forEach(link => link.addEventListener('click', () => menu.classList.remove('aberto')));
