# TCC — Rastreio de Autismo na Puericultura

Site estático em HTML, CSS e JavaScript para apresentação acadêmica.

## Como abrir no VS Code
1. Extraia o arquivo ZIP.
2. No VS Code, vá em **File > Open Folder** e selecione `TCC_Rastreio_Autismo`.
3. Abra `index.html`.
4. Com Live Server instalado, clique com o botão direito em `index.html` > **Open with Live Server**.

## Estrutura
- `index.html`: conteúdo do site.
- `style.css`: cores, layout e responsividade.
- `script.js`: menu mobile.
- `assets/hero-tcc-autismo.png`: arte visual principal.

## Importante
Os textos metodológicos e resultados são demonstrativos. Antes de uso acadêmico, substitua-os pelos dados, instrumento, método, resultados, referências e conclusão reais do TCC. O site diferencia rastreio de diagnóstico e não associa vacinação ao autismo.
